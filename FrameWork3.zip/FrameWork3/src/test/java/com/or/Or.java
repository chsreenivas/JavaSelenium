package com.or;

import org.openqa.selenium.By;

public class Or {
	
	public static By signinlnk = By.xpath("//a[@class='login']");
	public static By userNameTxtField = By.xpath("//input[@id='email']");
	public static By passwordTxtField = By.xpath("//input[@id='passwd']");
	public static By signinBtn = By.xpath("//button[@id='SubmitLogin']//span");
}
