package com.business;

import org.openqa.selenium.WebDriver;

import com.actionDriver.ActionDriver;
import com.or.Or;

import May.FrameWork3.Base;

public class BusinessFuncitons {
	
	public WebDriver driver;
	public ActionDriver actionD;
	
	public BusinessFuncitons() {
		
		driver = Base.driver;
		actionD = new ActionDriver();
	}
	
	public void url() throws Exception {
		Base.childTest = Base.parentTest.createNode("Loggin into URL");
		actionD.url("http://automationpractice.com/index.php");
	}
	
	public void clcikOnSignInLink() throws Exception {
		Base.childTest = Base.parentTest.createNode("clicking on signin Link");
		actionD.click(Or.signinlnk, "Sign in Link");
		
	}
	public void sendKeysUsername() throws Exception {
		Base.childTest = Base.parentTest.createNode("Entering Username");
		actionD.sendKeys(Or.userNameTxtField, "Srinivas");
		
	}
	public void sendKeysPassword() throws Exception {
		Base.childTest = Base.parentTest.createNode("Entering password");
		actionD.sendKeys(Or.passwordTxtField, "Srinivas");
		
	}
	public void clickOnSigninBtn() throws Exception {
		Base.childTest = Base.parentTest.createNode("Clicking on Sigin button");
		actionD.click(Or.signinBtn, "SignIn buttons");
		
	}
	
	
	
	
}
