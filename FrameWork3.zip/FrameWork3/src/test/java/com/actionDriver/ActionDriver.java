package com.actionDriver;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;

import May.FrameWork3.Base;

import org.openqa.selenium.TakesScreenshot;


public class ActionDriver {
	
	public  WebDriver driver;
	
	public ActionDriver() {
		driver = Base.driver;
		
	}
	
	public void url(String url) throws Exception {
		
		try {
			
			driver.get(url);
			Base.childTest.pass("able to login");
		}
		catch(Exception e){
			
			e.printStackTrace();
			takeScreenshot();
			Base.childTest.fail("Not able to navigate");
		}
		
		
	}
	
	public void takeScreenshot() throws Exception {
		
		UUID uuid = UUID.randomUUID();
		
		File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(scr, new File("/Users/alliancetech/Desktop/FrameWorkD/FrameWork3/Reports/"+uuid+".jpg"));
	}
	
	
	public void click(By by, String string) throws Exception {
		
		try {
			
			driver.findElement(by).click();
			Base.childTest.pass("Able to click on "+ string);
			takeScreenshot();
		}
		catch(Exception e) {
			
			e.printStackTrace();
			Base.childTest.fail("Not avle to click on "+ string);
			takeScreenshot();
			
		}
		
	}
	
	public void sendKeys(By by, String string) {
		try {
			
			driver.findElement(by).sendKeys(string);
			takeScreenshot();
			Base.childTest.pass("Able to send Keys on " + string);
		}
		catch(Exception e) {
			
			e.printStackTrace();
			Base.childTest.fail("Not able to send keys"+ string);
		}
		
	}
	

}
