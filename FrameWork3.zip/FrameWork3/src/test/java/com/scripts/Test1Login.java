package com.scripts;

import org.testng.annotations.Test;

import com.business.BusinessFuncitons;

import May.FrameWork3.Base;

public class Test1Login extends Base{
  @Test
  public void test1Login() throws Exception {
	  BusinessFuncitons bp = new BusinessFuncitons();
	  bp.url();
	  bp.clcikOnSignInLink();
	  bp.sendKeysUsername();
	  bp.sendKeysPassword();
	  bp.clickOnSigninBtn();
	  
  }
}
